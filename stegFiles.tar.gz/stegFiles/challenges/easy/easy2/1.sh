#!/bin/bash

for i in `seq 1 10000`; do
	echo "THIS IS NOT A SECRET MESSAGE." >  $i
done

